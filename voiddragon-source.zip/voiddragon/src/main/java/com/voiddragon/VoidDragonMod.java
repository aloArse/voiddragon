package com.voiddragon;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;

@Mod(VoidDragonMod.MODID)
public class VoidDragonMod {
    public static final String MODID = "voiddragon";

    public VoidDragonMod(IEventBus modEventBus) {
        ModEntities.ENTITIES.register(modEventBus);
        ModItems.ITEMS.register(modEventBus);
        ModTabs.TABS.register(modEventBus);
    }
}
